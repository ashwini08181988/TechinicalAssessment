﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TechnicalAssessment.Models;

namespace TechnicalAssessment.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            List<Car> cars = LoadCars().ToList();
            return View(cars);
        }

        //calculate the newest vehicles in order
        public ActionResult NewestVehicles()
        {
            List<Car> cars = LoadCars().ToList();
            var newestVehicles = cars.OrderByDescending(x => x.Year).ToList();
            return View(newestVehicles);
        }

        //calculate an alphabetized List of vehicles
        public ActionResult Alphabetizedist()
        {
            List<Car> cars = LoadCars().ToList();
            var alphabetizedist = cars.OrderBy(x => x.Make).ThenBy(x => x.Model).ToList();
            return View(alphabetizedist);
        }

        //calculate an ordered List of Vehicles by Price
        public ActionResult VehiclesByPriceist()
        {
            List<Car> cars = LoadCars().ToList();
            var vehiclesByPriceist = cars.OrderBy(x => x.Price).ToList();
            return View(vehiclesByPriceist);
        }

        //return average MPG by year
        public ActionResult AverageMPGPerYear()
        {
            List<Car> cars = LoadCars().ToList();
            List<AverageMPGPerYear> averageMPGPerYear = new List<AverageMPGPerYear>();
            var result = cars.GroupBy(x => new { Year = x.Year }).Select(y => new { Average = y.Average(z => z.HwyMPG), Year = y.Key.Year });
            averageMPGPerYear = result.Select(c => new AverageMPGPerYear() { Year = c.Year, MPGPerYear = c.Average }).ToList();
            return View(averageMPGPerYear);
        }

        //return a random car from the list
        public ActionResult RandomCar()
        {
            List<Car> cars = LoadCars().ToList();
            Random rnd = new Random();
            int r = rnd.Next(cars.Count);
            var randomCar = new Car()
            {
                Make = cars[r].Make,
                Model = cars[r].Model,
                Color = cars[r].Color,
                Year = cars[r].Year,
                Price = cars[r].Price,
                TCCRating = cars[r].TCCRating,
                HwyMPG = cars[r].HwyMPG
            };
            return View(randomCar);
        }

        //calculate fuel consumption for a given distance
        [HttpGet]
        public ActionResult FuelConsumptionForAGivenDistance()
        {
            var fuelConsumption = new FuelConsumption();
            return View(fuelConsumption);
        }

        [HttpPost]
        public ActionResult FuelConsumptionOutPut(FuelConsumption fuelConsumption)
        {
            List<Car> cars = LoadCars().ToList();
            foreach (var item in cars)
            {
                item.FuelConsumptioPerGivenDistace = fuelConsumption.Miles / item.HwyMPG;
            }
            var result = new FuelConsumption { Miles = fuelConsumption.Miles, Cars = cars };
            return View(result);
        }
        private IList<Car> LoadCars()
        {
            IList<Car> cars = new List<Car>();
            cars.Add(new Car { Make = "Honda", Model = "CRV", Color = "Green", Year = 2016, Price = 23845, TCCRating = 8, HwyMPG = 33 });
            cars.Add(new Car { Make = "Ford", Model = "Escape ", Color = "Red", Year = 2017, Price = 23590, TCCRating = 7.8f, HwyMPG = 32 });
            cars.Add(new Car { Make = "Hyundai", Model = "SanteFe", Color = "Gray", Year = 2017, Price = 24950, TCCRating = 8, HwyMPG = 27 });
            cars.Add(new Car { Make = "Mazda", Model = "CX-5", Color = "Red", Year = 2017, Price = 21795, TCCRating = 8, HwyMPG = 35 });
            cars.Add(new Car { Make = "Subaru", Model = "Forester", Color = "Blue", Year = 2016, Price = 22395, TCCRating = 8.4f, HwyMPG = 32 });

            return cars;
        }
    }
}
